package temperatureconverter;

public class TemperatureConverter {

    public static void main(String[] args) {
        Convert con = new Convert();
        con.setVisible(true);
    }

}
